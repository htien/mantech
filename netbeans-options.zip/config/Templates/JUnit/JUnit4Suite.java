<#-- FreeMarker template (see http://freemarker.org/) -->
<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};

</#if>
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author ${user}
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} ${userid} Exp $
 */
<#-- classNames:  "FooA,FooB" -->
<#-- classes:     "FooA.class,FooB.class" -->
@RunWith(Suite.class)
@Suite.SuiteClasses({${classes}})
public class ${name} {

}