<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">
<#if package?? && package != "">
package ${package};

</#if>
/**
 *
 * @author ${user}
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} ${userid} Exp $
 */
public class ${name} extends Exception {

    /**
     * Creates a new instance of <code>${name}</code> without detail message.
     */
    public ${name}() {
    }

    /**
     * Constructs an instance of <code>${name}</code> with the specified detail message.
     * @param msg the detail message.
     */
    public ${name}(String msg) {
        super(msg);
    }
}
