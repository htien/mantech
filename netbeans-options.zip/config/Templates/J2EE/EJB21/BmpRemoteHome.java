<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../../Licenses/license-${project.license}.txt">
package ${package};

import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;

/**
 * @author Lilylnx C.
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} lilylnxc Exp $
 */
public interface ${name} extends EJBHome {

    ${remoteInterface} findByPrimaryKey(${primaryKey} key)  throws FinderException, RemoteException;
    
}
