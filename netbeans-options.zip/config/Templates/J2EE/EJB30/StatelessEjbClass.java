<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../../Licenses/license-${project.license}.txt">
<#if package?? && package != "">
package ${package};

</#if>
import javax.ejb.Stateless;
<#if annotationLocalBean??>
import javax.ejb.LocalBean;
</#if>

/**
 * @author Lilylnx C.
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} lilylnxc Exp $
 */
@Stateless
<#if annotationLocalBean??>
@LocalBean
</#if>
public class ${name} <#if interfaces??>implements ${interfaces} </#if>{
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
 
}
