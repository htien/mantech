<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../../Licenses/license-${project.license}.txt">
<#if package?? && package != "">
package ${package};

</#if>
import javax.ejb.Singleton;
<#if annotationLocalBean??>
import javax.ejb.LocalBean;
</#if>

/**
 * @author ${user}
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} lilylnxc Exp $
 */
@Singleton
<#if annotationLocalBean??>
@LocalBean
</#if>
public class ${name} <#if interfaces??>implements ${interfaces} </#if>{
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
 
}
