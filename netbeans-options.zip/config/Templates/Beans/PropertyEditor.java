<#-- FreeMarker template (see http://freemarker.org/) -->
<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};

</#if>
import java.beans.*;

/**
 *
 * @author ${user}
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} ${userid} Exp $
 */
public class ${name} extends PropertyEditorSupport {

    public ${name}() {
    }

}
