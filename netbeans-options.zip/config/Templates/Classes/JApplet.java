<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">
<#if package?? && package != "">
package ${package};

</#if>
import javax.swing.JApplet;

/**
 *
 * @author ${user}
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} ${userid} Exp $
 */
public class ${name} extends JApplet {

    /**
     * Initialization method that will be called after the applet is loaded
     * into the browser.
     */
    public void init() {
        // TODO start asynchronous download of heavy resources
    }

    // TODO overwrite start(), stop() and destroy() methods

}
