<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">
<#if package?? && package != "">
package ${package};

</#if>
/**
 * @author Lilylnx C.
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} lilylnxc Exp $
 */
public class ${name} {

    private ${name}() {
    }

    public static ${name} getInstance() {
        return ${name}Holder.INSTANCE;
    }

    private static class ${name}Holder {
        private static final ${name} INSTANCE = new ${name}();
    }

 }
