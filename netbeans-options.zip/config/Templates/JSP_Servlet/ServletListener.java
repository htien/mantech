<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">

<#if package?? && package != "">
package ${package};
</#if>

<#if classAnnotation??>
import javax.servlet.annotation.WebListener;

</#if>
/**
 * Web application lifecycle listener.
 * @author ${user}
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} ${userid} Exp $
 */
<#if classAnnotation??>
${classAnnotation}
</#if>
public class ${name} {
}
