<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "../Licenses/license-${project.license}.txt">
<#if package?? && package != "">
package ${package};

</#if>
/**
 * @author Lilylnx C.
 * @version $Id: ${nameAndExt},v 1.0 ${date?date?string("yyyy/MM/dd")} ${time?time?string("H:m:s")} lilylnxc Exp $
 */
public class ${name} {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
